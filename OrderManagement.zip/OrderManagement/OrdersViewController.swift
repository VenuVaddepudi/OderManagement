import UIKit
import CoreData


class OrdersViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, AddEditOrderDelegate, OrderTableViewCellDelegate {

    // MARK: - Properties
    var currentUser: User!
    private var orders: [Order] = []
    private let context: NSManagedObjectContext
    private let tableView = UITableView()
    private var emptyStateLabel: UILabel?
    private let logoutButton = UIButton(type: .system)
    // MARK: - Initialization
    init(currentUser: User, context: NSManagedObjectContext) {
        self.currentUser = currentUser
        self.context = context
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented - use init(currentUser:context:)")
    }

    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        setupNavigationBar()
        setupTableView()
        fetchOrders()
        setupLogoutButton()
        assert(currentUser != nil, "CurrentUser must be provided to OrdersViewController")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchOrders()
    }

    // MARK: - UI Setup
    private func setupNavigationBar() {
        if let username = currentUser.username {
            title = "\(username)'s Orders"
        } else {
            title = "My Orders"
        }
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewOrderTapped))
        navigationItem.leftBarButtonItem = nil
    }

    private func setupTableView() {
           tableView.translatesAutoresizingMaskIntoConstraints = false
           tableView.dataSource = self
           tableView.delegate = self
           // Use the view controller's background color
           tableView.backgroundColor = view.backgroundColor
           tableView.register(OrderTableViewCell.self, forCellReuseIdentifier: OrderTableViewCell.identifier)
           tableView.estimatedRowHeight = 60 // Adjust estimate for list style
           tableView.rowHeight = UITableView.automaticDimension
           // *** Use standard separators ***
           tableView.separatorStyle = .singleLine
           tableView.tableFooterView = UIView() // Hide extra separators
           tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0) // Keep bottom padding
           view.addSubview(tableView)

           NSLayoutConstraint.activate([
               tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
               tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
               tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
               tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
           ])
       }

    private func setupLogoutButton() {
        // Style the button
        var config = UIButton.Configuration.filled() // Use modern configuration
        config.title = "Logout"
        config.image = UIImage(systemName: "rectangle.portrait.and.arrow.right")
        config.imagePadding = 8
        config.baseBackgroundColor = .systemRed // Use red for potentially destructive/final actions
        config.baseForegroundColor = .white
        config.cornerStyle = .capsule // Fully rounded corners

        // Apply configuration and add action
        logoutButton.configuration = config
        logoutButton.addTarget(self, action: #selector(logoutTapped), for: .touchUpInside)

        // Add shadow for floating effect (optional)
        logoutButton.layer.shadowColor = UIColor.black.cgColor
        logoutButton.layer.shadowOffset = CGSize(width: 0, height: 3)
        logoutButton.layer.shadowRadius = 5
        logoutButton.layer.shadowOpacity = 0.3

        // Add to view and set constraints
        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logoutButton) // Add to the main view, not the table view

        // Constraints for bottom-right corner
        NSLayoutConstraint.activate([
            logoutButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            logoutButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
            // Let the button size itself based on configuration, or add height/width if needed
        ])

        // *** IMPORTANT: Adjust TableView Content Inset ***
        // Make sure the table view content scrolls up enough so the last
        // row isn't hidden behind the floating logout button.
        // Calculate button height (approximate or measure if needed)
        let buttonHeight: CGFloat = 50 // Estimate based on configuration padding
        let bottomPadding: CGFloat = 20 // Padding below button
        tableView.contentInset.bottom = buttonHeight + bottomPadding + 10 // Add extra space
        // Also adjust scroll indicator insets
        tableView.scrollIndicatorInsets.bottom = tableView.contentInset.bottom

    }
    // MARK: - Core Data Operations
    private func fetchOrders() {
        let fetchRequest: NSFetchRequest<Order> = Order.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "createdBy == %@", currentUser)
        let sortByDueDate = NSSortDescriptor(key: "orderDueDate", ascending: true)
        fetchRequest.sortDescriptors = [sortByDueDate]

        do {
            orders = try context.fetch(fetchRequest)
            print("Fetched \(orders.count) orders for user \(currentUser.username ?? "N/A")")
            DispatchQueue.main.async {
                self.tableView.reloadData()
                self.updateEmptyState()
            }
        } catch {
            print("Failed to fetch orders: \(error)")
            DispatchQueue.main.async {
                self.showAlert(title: "Fetch Error", message: "Could not load orders: \(error.localizedDescription)")
                self.showEmptyStateLabel("Error loading orders.")
            }
        }
    }
    // Inside OrdersViewController.swift

    @objc private func logoutTapped() {
        print("Logout button tapped")

        // *** FORGET USER ***
        UserDefaults.standard.removeObject(forKey: "lastLoggedInUsername")
        print("Removed username from UserDefaults")

        let viewOrderVC = ViewController()
        viewOrderVC.navigationItem.hidesBackButton = true

        self.navigationController?.pushViewController(viewOrderVC, animated: true)
    }

    private func saveContext() {
        guard context.hasChanges else { return }
        do {
            try context.save()
            print("Context saved successfully.")
        } catch {
            print("Failed to save context: \(error)")
            showAlert(title: "Save Error", message: "Could not save changes: \(error.localizedDescription)")
        }
    }

    // MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orders.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderTableViewCell.identifier, for: indexPath) as? OrderTableViewCell else {
            fatalError("Unable to dequeue OrderTableViewCell")
        }
        let order = orders[indexPath.row]
        cell.configure(with: order)
        cell.delegate = self
        return cell
    }

    // MARK: - UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Keep tap for viewing details, deselect handled in cell now (selectionStyle = .none)
        guard indexPath.row < orders.count else { return }
        let selectedOrder = orders[indexPath.row]
        print("Selected order to view: \(selectedOrder.orderNumber)")
        let viewOrderVC = ViewOrderViewController()
        viewOrderVC.order = selectedOrder
        navigationController?.pushViewController(viewOrderVC, animated: true)
    }

    // --- Action Handlers ---
    @objc private func addNewOrderTapped() {
        print("Navigation bar Add button tapped")
        showAddEditScreen(orderToEdit: nil)
    }

    private func showAddEditScreen(orderToEdit: Order?) {
        let addEditVC = AddEditOrderViewController()
        addEditVC.delegate = self
        addEditVC.context = self.context
        addEditVC.currentUser = self.currentUser
        addEditVC.orderToEdit = orderToEdit
        let navController = UINavigationController(rootViewController: addEditVC)
        navController.modalPresentationStyle = .automatic
        present(navController, animated: true, completion: nil)
    }

    private func confirmAndDeleteOrder(_ orderToDelete: Order, at indexPath: IndexPath) {
        let orderNumber = orderToDelete.orderNumber
        let alert = UIAlertController(
            title: "Confirm Delete",
            message: "Are you sure you want to delete order \(orderNumber)? This action cannot be undone.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [weak self] _ in
            guard let self = self else { return }
            self.context.delete(orderToDelete)
            self.saveContext()
            self.orders.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
            self.updateEmptyState()
            print("Deleted order: \(orderNumber)")
        }))
        present(alert, animated: true, completion: nil)
    }

    // MARK: - Delegate Implementations

    // AddEditOrderDelegate
    func didSaveOrder() {
        print("OrdersViewController notified: Order was saved. Refetching...")
        fetchOrders()
    }

    // OrderTableViewCellDelegate
    func orderTableViewCellDidTapEdit(_ cell: OrderTableViewCell) {
        guard let indexPath = tableView.indexPath(for: cell), indexPath.row < orders.count else {
            print("Error: Could not find index path for edit button tap in cell: \(cell)")
            return
        }
        let orderToEdit = orders[indexPath.row]
        print("Editing order via cell button: \(orderToEdit.orderNumber)")
        showAddEditScreen(orderToEdit: orderToEdit)
    }

    func orderTableViewCellDidTapDelete(_ cell: OrderTableViewCell) {
        guard let indexPath = tableView.indexPath(for: cell), indexPath.row < orders.count else {
            print("Error: Could not find index path for delete button tap in cell: \(cell)")
            return
        }
        let orderToDelete = orders[indexPath.row]
        print("Deleting order via cell button: \(orderToDelete.orderNumber)")
        confirmAndDeleteOrder(orderToDelete, at: indexPath)
    }

    // MARK: - UI Helpers
    private func updateEmptyState() {
        if orders.isEmpty {
            showEmptyStateLabel("No orders found.\nTap '+' in the top right to add one.")
        } else {
            hideEmptyStateLabel()
        }
    }

    private func showEmptyStateLabel(_ message: String) {
        if emptyStateLabel == nil {
            emptyStateLabel = UILabel()
            emptyStateLabel?.textAlignment = .center
            emptyStateLabel?.textColor = .secondaryLabel
            emptyStateLabel?.font = UIFont.preferredFont(forTextStyle: .title3)
            emptyStateLabel?.numberOfLines = 0
           
            emptyStateLabel?.translatesAutoresizingMaskIntoConstraints = false
            let backgroundContainer = UIView()
            backgroundContainer.addSubview(emptyStateLabel!)
            tableView.backgroundView = backgroundContainer
            NSLayoutConstraint.activate([
                 emptyStateLabel!.centerXAnchor.constraint(equalTo: backgroundContainer.centerXAnchor),
                 emptyStateLabel!.centerYAnchor.constraint(equalTo: backgroundContainer.centerYAnchor, constant: -20),
                 emptyStateLabel!.leadingAnchor.constraint(greaterThanOrEqualTo: backgroundContainer.leadingAnchor, constant: 20),
                 emptyStateLabel!.trailingAnchor.constraint(lessThanOrEqualTo: backgroundContainer.trailingAnchor, constant: -20)
            ])
        }
        emptyStateLabel?.text = message
        tableView.backgroundView?.isHidden = false
        tableView.separatorStyle = .none
    }

    private func hideEmptyStateLabel() {
        tableView.backgroundView?.isHidden = true
        // Separator style is already none, no need to change back
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        DispatchQueue.main.async {
            self.present(alert, animated: true)
        }
    }
}
