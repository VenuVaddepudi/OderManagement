import UIKit
import CoreData

class ViewOrderViewController: UIViewController {

    // --- Properties ---
    var order: Order! // Must be passed

    // --- UI Elements ---
    // Container and main layout
    private let scrollView = UIScrollView()
    private let contentView = UIView()
    private let mainStackView = UIStackView() // Holds everything vertically

    // Order Section
    private let orderHeaderLabel = UILabel()
    private let orderNumberLabel = UILabel()
    private let dueDateLabel = UILabel()
    private let totalLabel = UILabel()

    // Customer Section
    private let customerHeaderLabel = UILabel()
    private let customerNameLabel = UILabel()
    private let phoneLabel = UILabel()
    private let addressLabel = UILabel()


    // --- Formatters ---
    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium // Medium style for better readability
        formatter.timeStyle = .short
        return formatter
    }()

    private static let currencyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter
    }()

    // --- Lifecycle ---
    override func viewDidLoad() {
        super.viewDidLoad()
        // Use grouped background for a classic feel
        view.backgroundColor = .systemGroupedBackground
        assert(order != nil, "Order object must be provided")
        setupNavigationBar()
        setupScrollView() // Setup scroll view first
        setupUI()         // Add UI elements inside scroll view's content
        populateData()
    }

    // --- Setup ---

    /// Sets up the navigation bar title.
    private func setupNavigationBar() {
        title = "Order Details"
        navigationItem.largeTitleDisplayMode = .never // Standard title size for detail views
    }

    /// Sets up the scroll view structure.
    private func setupScrollView() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        // Pin scroll view to safe area
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),

            // Pin content view to scroll view's content area
            contentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            // Crucial: Make content view width match scroll view frame width
            contentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        ])
    }

    /// Configures and lays out the UI elements within the contentView.
    private func setupUI() {
        // Configure Main Stack View (Vertical)
        mainStackView.axis = .vertical
        mainStackView.spacing = 20 // Space between sections
        mainStackView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(mainStackView) // Add to scroll view's content

        // --- Order Section ---
        configureHeaderLabel(orderHeaderLabel, text: "ORDER INFORMATION")
        let orderDetailsStack = createVerticalDetailStack(pairs: [
            createLabelPair(prefix: "Number:", valueLabel: orderNumberLabel),
            createLabelPair(prefix: "Due Date:", valueLabel: dueDateLabel),
            createLabelPair(prefix: "Total:", valueLabel: totalLabel, valueFontWeight: .semibold) // Emphasize total slightly
        ])

        // --- Customer Section ---
        configureHeaderLabel(customerHeaderLabel, text: "CUSTOMER DETAILS")
        let customerDetailsStack = createVerticalDetailStack(pairs: [
            createLabelPair(prefix: "Name:", valueLabel: customerNameLabel),
            createLabelPair(prefix: "Phone:", valueLabel: phoneLabel),
            createLabelPair(prefix: "Address:", valueLabel: addressLabel, alignTop: true) // Align address prefix top
        ])

        // Configure Value Labels (allow multiple lines)
        configureValueLabel(orderNumberLabel)
        configureValueLabel(dueDateLabel)
        configureValueLabel(totalLabel)
        configureValueLabel(customerNameLabel)
        configureValueLabel(phoneLabel)
        configureValueLabel(addressLabel) // Ensure address can wrap

        // Add Sections to Main Stack View
        mainStackView.addArrangedSubview(orderHeaderLabel)
        mainStackView.addArrangedSubview(orderDetailsStack)
        mainStackView.addArrangedSubview(customerHeaderLabel)
        mainStackView.addArrangedSubview(customerDetailsStack)

        // --- Constraints for Main StackView within ContentView ---
        NSLayoutConstraint.activate([
            mainStackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            mainStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            mainStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
            // Ensure stack view defines content height for scrolling
            mainStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }

    /// Populates the labels with data from the order object.
    private func populateData() {
        orderNumberLabel.text = order.orderNumber
        customerNameLabel.text = order.customerBuyerName ?? "N/A"
        addressLabel.text = order.customerAddress?.isEmpty == false ? order.customerAddress : "N/A" // Handle empty string too
        phoneLabel.text = order.customerPhone?.isEmpty == false ? order.customerPhone : "N/A"

        if let dueDate = order.orderDueDate {
            dueDateLabel.text = Self.dateFormatter.string(from: dueDate)
        } else {
            dueDateLabel.text = "N/A"
        }

        let totalAmount = NSNumber(value: order.orderTotal)
        totalLabel.text = Self.currencyFormatter.string(from: totalAmount) ?? "rupeesign.ring0.00"
    }

    // --- UI Helper Methods ---

    /// Configures the appearance of section header labels.
    private func configureHeaderLabel(_ label: UILabel, text: String) {
        label.text = text
        label.font = UIFont.preferredFont(forTextStyle: .caption1) // Standard section header font
        label.textColor = .secondaryLabel // Subtle header color
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    /// Configures the appearance of the labels displaying the actual order/customer data.
    private func configureValueLabel(_ label: UILabel) {
        label.font = UIFont.preferredFont(forTextStyle: .body) // Standard body text
        label.textColor = .label
        label.numberOfLines = 0 // Allow wrapping for long text like addresses
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    /// Creates a vertical stack view containing label pairs, optionally within a background view.
    private func createVerticalDetailStack(pairs: [UIStackView]) -> UIView {
        // Container view for visual grouping (card-like within the section)
        let containerView = UIView()
        containerView.backgroundColor = .secondarySystemGroupedBackground // Background for the group
        containerView.layer.cornerRadius = 10
        containerView.translatesAutoresizingMaskIntoConstraints = false

        let stack = UIStackView(arrangedSubviews: pairs)
        stack.axis = .vertical
        stack.spacing = 10 // Space between rows within a section
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false

        containerView.addSubview(stack)

        // Add padding inside the container view
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 15),
            stack.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 15),
            stack.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -15),
            stack.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -15)
        ])

        return containerView
    }


    /// Creates a horizontal stack view containing a prefix label (e.g., "Name:") and a value label.
    private func createLabelPair(prefix: String, valueLabel: UILabel, valueFontWeight: UIFont.Weight = .regular, alignTop: Bool = false) -> UIStackView {
        let prefixLabel = UILabel()
        prefixLabel.text = prefix
        prefixLabel.font = UIFont.preferredFont(forTextStyle: .body) // Same size as value
        prefixLabel.textColor = .secondaryLabel // Differentiate prefix
        prefixLabel.translatesAutoresizingMaskIntoConstraints = false
        // Set a fixed width or compression resistance to ensure consistent alignment
        prefixLabel.setContentCompressionResistancePriority(.required, for: .horizontal)
        prefixLabel.setContentHuggingPriority(.defaultHigh + 1, for: .horizontal)
        // Set explicit width for better column alignment (adjust as needed)
        prefixLabel.widthAnchor.constraint(equalToConstant: 85).isActive = true

        // Apply custom weight to value label if specified
        if valueFontWeight != .regular {
            if let currentFont = valueLabel.font {
                valueLabel.font = UIFont.systemFont(ofSize: currentFont.pointSize, weight: valueFontWeight)
            }
        }

        let pairStackView = UIStackView(arrangedSubviews: [prefixLabel, valueLabel])
        pairStackView.axis = .horizontal
        pairStackView.spacing = 8 // Space between prefix and value
        
        // Align text baselines, or top for multi-line fields like address
        pairStackView.alignment = alignTop ? .top : .firstBaseline
        pairStackView.translatesAutoresizingMaskIntoConstraints = false
        return pairStackView
    }
}
