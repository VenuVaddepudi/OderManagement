import UIKit
import CoreData // Make sure this is imported

// 1. Add UITextFieldDelegate conformance
class ViewController: UIViewController, UITextFieldDelegate {

   // --- UI Elements ---
   let headingLabel = UILabel()
   let toggleInfoLabel = UILabel()
   let usernameTextField = UITextField()
   let passwordTextField = UITextField()
   let confirmPasswordTextField = UITextField()
   let actionButton = UIButton(type: .system)
   let toggleModeButton = UIButton(type: .system)
   let stackView = UIStackView()

   // State
   var isLoginMode = true

   // --- Lifecycle ---
   override func viewDidLoad() {
       super.viewDidLoad()
       view.backgroundColor = .systemGroupedBackground
       setupUI()
       setupConstraints()
       updateUIForMode()
      
   }

   // --- UI Setup ---
   func setupUI() {
       // Stack View Configuration
       stackView.axis = .vertical
       stackView.spacing = 15
       stackView.alignment = .fill
       stackView.translatesAutoresizingMaskIntoConstraints = false

       // Heading Label
       headingLabel.font = UIFont.preferredFont(forTextStyle: .largeTitle)
       headingLabel.textAlignment = .center
       headingLabel.textColor = .label

       // Text Fields (Classic Style)
       usernameTextField.placeholder = "Username"
       usernameTextField.borderStyle = .roundedRect
       usernameTextField.autocorrectionType = .no
       usernameTextField.autocapitalizationType = .none
       usernameTextField.returnKeyType = .next
       usernameTextField.delegate = self // Assign delegate

       passwordTextField.placeholder = "Password"
       passwordTextField.borderStyle = .roundedRect
       passwordTextField.isSecureTextEntry = true
       passwordTextField.returnKeyType = .done
       passwordTextField.delegate = self // Assign delegate

       confirmPasswordTextField.placeholder = "Confirm Password"
       confirmPasswordTextField.borderStyle = .roundedRect
       confirmPasswordTextField.isSecureTextEntry = true
       confirmPasswordTextField.returnKeyType = .done
       confirmPasswordTextField.delegate = self // Assign delegate

       // Action Button (Login/Register)
       actionButton.backgroundColor = .systemBlue
       actionButton.setTitleColor(.white, for: .normal)
       actionButton.layer.cornerRadius = 8
       actionButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
       actionButton.addTarget(self, action: #selector(actionButtonTapped), for: .touchUpInside)
       // Using intrinsic content size + padding often works better than fixed height,
       // but fixed height is okay too. Let's keep yours for now:
       actionButton.heightAnchor.constraint(equalToConstant: 44).isActive = true // Standard touch target height


       // Toggle Info Label (Non-clickable text)
       toggleInfoLabel.font = UIFont.preferredFont(forTextStyle: .footnote)
       toggleInfoLabel.textColor = .secondaryLabel
       toggleInfoLabel.textAlignment = .center

       // Toggle Mode Button (Clickable link-style button)
       toggleModeButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .callout)
       toggleModeButton.setTitleColor(.systemBlue, for: .normal)
       toggleModeButton.addTarget(self, action: #selector(toggleModeButtonTapped), for: .touchUpInside)


       // --- Assemble Stack View ---
       stackView.addArrangedSubview(headingLabel)
       stackView.setCustomSpacing(20, after: headingLabel) // Add space after title
       stackView.addArrangedSubview(usernameTextField)
       stackView.addArrangedSubview(passwordTextField)
       stackView.addArrangedSubview(confirmPasswordTextField) // Will be hidden/shown
       stackView.setCustomSpacing(25, after: confirmPasswordTextField) // Add extra space before button
       stackView.addArrangedSubview(actionButton)
       stackView.setCustomSpacing(20, after: actionButton) // Add space before toggle info
       stackView.addArrangedSubview(toggleInfoLabel)
       stackView.addArrangedSubview(toggleModeButton)
       stackView.setCustomSpacing(5, after: toggleInfoLabel) // Less space between info and toggle button


       view.addSubview(stackView)
   }

   func setupConstraints() {
       NSLayoutConstraint.activate([
           // Stack View Constraints
           stackView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
           stackView.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor, constant: -30), // Move up slightly
           stackView.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor, multiplier: 0.85) // Adjust width
       ])
   }

   // --- UI Update Logic ---
   func updateUIForMode() {
       if isLoginMode {
           // Configure for Login
           headingLabel.text = "Login"
           actionButton.setTitle("Login", for: .normal)
           confirmPasswordTextField.isHidden = true
           toggleInfoLabel.text = "Don't have an account?"
           toggleModeButton.setTitle("Register here", for: .normal)
           passwordTextField.returnKeyType = .done // Last field in login
       } else {
           // Configure for Registration
           headingLabel.text = "Register"
           actionButton.setTitle("Register", for: .normal)
           confirmPasswordTextField.isHidden = false
           toggleInfoLabel.text = "Already have an account?"
           toggleModeButton.setTitle("Login here", for: .normal)
           passwordTextField.returnKeyType = .next // Go to confirm password next
       }

       // Animate changes for smoother transition (optional)
       UIView.animate(withDuration: 0.2) {
           self.view.layoutIfNeeded()
       }
   }

   // --- Actions ---
    // Inside ViewController.swift

    @objc func actionButtonTapped() {
        view.endEditing(true)

        guard let username = usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !username.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showAlert(title: "Missing Information", message: "Please enter both username and password.")
            return
        }

        if isLoginMode {
            // --- Handle LOGIN ---
            print("Attempting Login...")
            if let user = authenticateUser(username: username, password: password) {
                print("Login Successful! User: \(user.username ?? "Unknown")")

                // *** REMEMBER USER ***
                UserDefaults.standard.set(user.username, forKey: "lastLoggedInUsername")
                print("Saved username '\(user.username ?? "N/A")' to UserDefaults")

                // Navigate after successful login
                navigateToOrdersScreen(user: user)
            } else {
                showAlert(title: "Login Failed", message: "Invalid username or password.")
                passwordTextField.text = ""
                passwordTextField.becomeFirstResponder()
            }

        } else {
            // --- Handle REGISTRATION ---
            // ... (Registration logic remains the same) ...
             guard let confirmPassword = confirmPasswordTextField.text, !confirmPassword.isEmpty else {
                 showAlert(title: "Missing Information", message: "Please confirm your password.")
                 confirmPasswordTextField.becomeFirstResponder()
                 return
             }

             guard password == confirmPassword else {
                 showAlert(title: "Password Mismatch", message: "The passwords entered do not match.")
                 passwordTextField.text = ""
                 confirmPasswordTextField.text = ""
                 passwordTextField.becomeFirstResponder()
                 return
             }

             guard !checkIfUserExists(username: username) else {
                 showAlert(title: "Registration Failed", message: "Username already taken. Please choose another.")
                 usernameTextField.becomeFirstResponder()
                 return
             }

             print("Attempting Registration...")
             if registerUser(username: username, password: password) {
                 print("Registration Successful!")
                 showAlert(title: "Registration Successful", message: "You can now log in.")
                 toggleModeButtonTapped()
             } else {
                 showAlert(title: "Registration Failed", message: "Could not save user. Please try again later.")
             }
        }
    }

   @objc func toggleModeButtonTapped() {
       isLoginMode.toggle() // Flip the mode
       updateUIForMode()    // Update the UI elements accordingly

       // Clear fields when switching modes for better UX
       usernameTextField.text = ""
       passwordTextField.text = ""
       confirmPasswordTextField.text = ""
       view.endEditing(true) // Dismiss keyboard if open
       // Optionally set focus to the first field
       // usernameTextField.becomeFirstResponder()
   }

   // --- Navigation ---
    func navigateToOrdersScreen(user: User) {
           print("Navigating to Orders Screen for user: \(user.username ?? "N/A")")

           guard let context = getContext() else {
               showAlert(title: "Error", message: "Could not access data store.")
               return
           }

           // Instantiate OrdersViewController with the required parameters
           let ordersVC = OrdersViewController(currentUser: user, context: context)

           // Embed OrdersVC in a Navigation Controller to get a Navigation Bar
           // for the title and the "Add" button.
           let navController = UINavigationController(rootViewController: ordersVC)
           navController.modalPresentationStyle = .fullScreen // Present full screen
           navController.modalTransitionStyle = .coverVertical // Standard transition

           present(navController, animated: true, completion: nil)

           // Clear login fields after successful navigation
           usernameTextField.text = ""
           passwordTextField.text = ""
       }


   // --- Helper Functions ---
   func showAlert(title: String, message: String) {
       let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
       alert.addAction(UIAlertAction(title: "OK", style: .default))
       // Ensure presentation happens on the main thread, especially if called from background tasks
       DispatchQueue.main.async {
            self.present(alert, animated: true)
       }
   }

   // --- Core Data Functions ---

   // Helper to get the Core Data context
    func getContext() -> NSManagedObjectContext? {
           guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
              print("Error: Could not get AppDelegate")
              return nil
          }
          return appDelegate.persistentContainer.viewContext
      }

    // Check if a user with the given username already exists
   func checkIfUserExists(username: String) -> Bool {
       guard let context = getContext() else { return true } // Assume exists if context fails

       let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
       // Case-insensitive check is usually better for usernames
       fetchRequest.predicate = NSPredicate(format: "username ==[c] %@", username)
       fetchRequest.fetchLimit = 1 // We only need to know if at least one exists

       do {
           let count = try context.count(for: fetchRequest)
           return count > 0
       } catch {
           print("Core Data Fetch Error checking user existence: \(error)")
           return true // Treat error as if user exists to prevent potential duplicates
       }
   }


   func registerUser(username: String, password: String) -> Bool {
       guard let context = getContext() else { return false }

       let newUser = User(context: context)
       newUser.username = username

       // --- !!! SECURITY WARNING !!! ---
       // NEVER store plain text passwords. HASH them securely!
       // This is just for demonstration. Replace with hashing.
       newUser.password = password
       // Example placeholder for hashing:
       // newUser.passwordHash = YourHashingLibrary.hash(password)
       // ---------------------------------

       do {
           try context.save()
           return true
       } catch {
           print("Core Data Registration Error: \(error)")
           context.rollback() // Rollback changes in case of error
           return false
       }
   }

   func authenticateUser(username: String, password: String) -> User? {
       guard let context = getContext() else { return nil }

       let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
       // Use case-insensitive comparison for username login
       fetchRequest.predicate = NSPredicate(format: "username ==[c] %@", username)
       fetchRequest.fetchLimit = 1 // Expecting only one user

       do {
           let results = try context.fetch(fetchRequest)
           if let user = results.first {
               // --- !!! SECURITY WARNING !!! ---
               // NEVER compare plain text passwords. Compare HASHES!
               // This is just for demonstration.
               if user.password == password {
               // Example placeholder for hash comparison:
               // if YourHashingLibrary.verify(password: password, matchesHash: user.passwordHash) {
                    return user // Correct password (or hash matches)
               } else {
                   print("Password mismatch for user: \(username)")
                   return nil // Incorrect password
               }
               // ---------------------------------
           } else {
               print("No user found with username: \(username)")
               return nil // User not found
           }
       } catch {
           print("Core Data Authentication Fetch Error: \(error)")
           return nil // Error during fetch
       }
   }

   // --- UITextFieldDelegate Methods ---

   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       if textField == usernameTextField {
           passwordTextField.becomeFirstResponder() // Move to password field
       } else if textField == passwordTextField {
           if isLoginMode {
               textField.resignFirstResponder() // Hide keyboard
               actionButtonTapped() // Trigger login on return
           } else {
               confirmPasswordTextField.becomeFirstResponder() // Move to confirm password field
           }
       } else if textField == confirmPasswordTextField {
           textField.resignFirstResponder() // Hide keyboard
           actionButtonTapped() // Trigger registration on return
       }
       return true // Indicate we handled the return key
   }

} // <-- End of ViewController class
