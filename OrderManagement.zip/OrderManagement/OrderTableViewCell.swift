import UIKit

// Delegate protocol to handle button taps
protocol OrderTableViewCellDelegate: AnyObject {
    func orderTableViewCellDidTapEdit(_ cell: OrderTableViewCell)
    func orderTableViewCellDidTapDelete(_ cell: OrderTableViewCell)
}

class OrderTableViewCell: UITableViewCell {

    // Reuse identifier
    static let identifier = "OrderTableViewCell"

    // Delegate property
    weak var delegate: OrderTableViewCellDelegate?

    // --- UI Elements ---
    private let orderNumberLabel = UILabel()
    private let customerNameLabel = UILabel()
    private let dueDateLabel = UILabel()
    private let totalLabel = UILabel()

    // Stack Views for layout
    private let infoStackView = UIStackView()      // Holds text labels vertically
    // Removed: private let buttonStackView = UIStackView() // Buttons positioned individually now

    // Action Buttons
    let editButton = UIButton(type: .system)
    let deleteButton = UIButton(type: .system)

    // --- Formatters ---
    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()

    private static let currencyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter
    }()

    // --- Initialization ---
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = .clear
        contentView.backgroundColor = .clear
        setupViews()
        setupLayout() // Layout logic updated for individual buttons
        setupButtonActions()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // --- Configuration ---
    func configure(with order: Order) {
        orderNumberLabel.text = order.orderNumber
        customerNameLabel.text = order.customerBuyerName ?? "N/A"

        if let dueDate = order.orderDueDate {
            dueDateLabel.text = "Due: \(Self.dateFormatter.string(from: dueDate))"
        } else {
            dueDateLabel.text = "No Date"
        }

        let totalAmount = NSNumber(value: order.orderTotal)
        totalLabel.text = Self.currencyFormatter.string(from: totalAmount) ?? "$0.00"
    }

    // --- Setup ---
    private func setupViews() {
        // --- Configure Labels --- (Appearance mostly unchanged)
        orderNumberLabel.font = UIFont.preferredFont(forTextStyle: .headline)
        orderNumberLabel.textColor = .label
        orderNumberLabel.numberOfLines = 1

        customerNameLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        customerNameLabel.textColor = .secondaryLabel
        customerNameLabel.numberOfLines = 1

        dueDateLabel.font = UIFont.preferredFont(forTextStyle: .footnote)
        dueDateLabel.textColor = .secondaryLabel
        dueDateLabel.numberOfLines = 1
        dueDateLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        totalLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        totalLabel.textColor = .systemBlue
        totalLabel.textAlignment = .right
        totalLabel.numberOfLines = 1
        totalLabel.setContentCompressionResistancePriority(.defaultHigh, for: .horizontal)
        totalLabel.setContentHuggingPriority(.defaultHigh, for: .horizontal)

        // --- Configure Buttons (Updated Icons & Color) ---
        configureButton(editButton, systemImageName: "square.and.pencil", color: .systemBlue) // Square icon, blue
        configureButton(deleteButton, systemImageName: "trash.square", color: .systemBlue)    // Square icon, blue

        // --- Configure Info Stack View ---
        let secondRowStack = UIStackView(arrangedSubviews: [customerNameLabel, dueDateLabel, totalLabel])
        secondRowStack.axis = .horizontal
        secondRowStack.spacing = 8
        secondRowStack.alignment = .firstBaseline

        infoStackView.axis = .vertical
        infoStackView.spacing = 4
        infoStackView.alignment = .leading
        infoStackView.translatesAutoresizingMaskIntoConstraints = false
        infoStackView.addArrangedSubview(orderNumberLabel)
        infoStackView.addArrangedSubview(secondRowStack)

        // --- Add subviews directly to contentView ---
        contentView.addSubview(infoStackView)
        contentView.addSubview(editButton)    // Add buttons individually
        contentView.addSubview(deleteButton)

        // Use default selection style
        self.selectionStyle = .default
    }

    /// Sets up the Auto Layout constraints with individually positioned buttons.
    private func setupLayout() {
        let verticalPadding: CGFloat = 11.0    // Standard vertical padding for list cells
        let horizontalPadding: CGFloat = 15.0  // Standard leading/trailing padding
        let buttonSize: CGFloat = 30           // Increased button size
        let infoButtonSpacing: CGFloat = 15.0   // Space between text and buttons
        // *** INCREASE this value to push buttons further apart vertically ***
        let buttonVerticalOffset: CGFloat = 20 // How far up/down from center buttons are positioned (was 12)

        NSLayoutConstraint.activate([
            // --- Info Stack Constraints ---
            infoStackView.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            infoStackView.topAnchor.constraint(equalTo: contentView.layoutMarginsGuide.topAnchor),
            infoStackView.bottomAnchor.constraint(equalTo: contentView.layoutMarginsGuide.bottomAnchor),
            // Info stack trailing is constrained relative to the leading edge of the EDIT button
            infoStackView.trailingAnchor.constraint(equalTo: editButton.leadingAnchor, constant: -infoButtonSpacing),

            // --- Edit Button Constraints (Top Right) ---
            editButton.widthAnchor.constraint(equalToConstant: buttonSize),
            editButton.heightAnchor.constraint(equalToConstant: buttonSize),
            editButton.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            // Position **further above** the center using the increased offset
            editButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor, constant: -buttonVerticalOffset), // Negative offset = Up

            // --- Delete Button Constraints (Bottom Right) ---
            deleteButton.widthAnchor.constraint(equalToConstant: buttonSize),
            deleteButton.heightAnchor.constraint(equalToConstant: buttonSize),
            deleteButton.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
             // Position **further below** the center using the increased offset
            deleteButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor, constant: buttonVerticalOffset), // Positive offset = Down

            // Safety constraint (can remain)
            deleteButton.leadingAnchor.constraint(greaterThanOrEqualTo: infoStackView.trailingAnchor, constant: infoButtonSpacing)

        ])

        // Vertical priorities for info stack
        infoStackView.setContentHuggingPriority(.defaultLow, for: .vertical)
        infoStackView.setContentCompressionResistancePriority(.defaultHigh, for: .vertical)
    }
    /// Helper to configure button appearance.
    private func configureButton(_ button: UIButton, systemImageName: String, color: UIColor) {
        // Adjust point size to match the larger buttonSize
        let config = UIImage.SymbolConfiguration(pointSize: 22, weight: .regular, scale: .default) // Increased point size
        button.setImage(UIImage(systemName: systemImageName, withConfiguration: config), for: .normal)
        button.tintColor = color
        button.setTitle(nil, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
    }

    /// Sets up the target actions for the buttons.
    private func setupButtonActions() {
        editButton.addTarget(self, action: #selector(editButtonTapped), for: .touchUpInside)
        deleteButton.addTarget(self, action: #selector(deleteButtonTapped), for: .touchUpInside)
    }

    // --- Button Actions ---
    @objc private func editButtonTapped() {
        delegate?.orderTableViewCellDidTapEdit(self)
    }

    @objc private func deleteButtonTapped() {
        delegate?.orderTableViewCellDidTapDelete(self)
    }

    // --- Prepare for Reuse ---
    override func prepareForReuse() {
        super.prepareForReuse()
        orderNumberLabel.text = nil
        customerNameLabel.text = nil
        dueDateLabel.text = nil
        totalLabel.text = nil
    }
}
