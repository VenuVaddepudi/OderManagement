import UIKit
import CoreData // Import CoreData

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    // Helper to easily access the persistent container from AppDelegate
    var persistentContainer: NSPersistentContainer? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    }

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        let window = UIWindow(windowScene: windowScene)
        self.window = window // Assign to the instance property

        // Check if a user was previously logged in
        if let lastUsername = UserDefaults.standard.string(forKey: "lastLoggedInUsername"),
           let context = persistentContainer?.viewContext { // Ensure context is available

            print("Found remembered username: \(lastUsername)")

            // Attempt to fetch the remembered user from Core Data
            if let user = fetchUser(username: lastUsername, context: context) {
                print("Successfully fetched remembered user: \(user.username ?? "N/A")")
                // User found, go directly to Orders screen
                let ordersVC = OrdersViewController(currentUser: user, context: context)
                let navController = UINavigationController(rootViewController: ordersVC)
                window.rootViewController = navController
            } else {
                print("Could not fetch user '\(lastUsername)' from Core Data. Clearing preference.")
                // User not found in Core Data (data inconsistency?), clear preference and show Login
                UserDefaults.standard.removeObject(forKey: "lastLoggedInUsername")
                window.rootViewController = ViewController() // Show Login screen
            }
        } else {
            print("No remembered username found. Showing Login screen.")
            // No remembered user, show Login screen
            window.rootViewController = ViewController()
        }

        window.makeKeyAndVisible()
    }

    /// Helper function to fetch a User by username from Core Data.
    /// - Parameters:
    ///   - username: The username to search for (case-insensitive).
    ///   - context: The managed object context to perform the fetch in.
    /// - Returns: The `User` object if found, otherwise `nil`.
    private func fetchUser(username: String, context: NSManagedObjectContext) -> User? {
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        // Use case-insensitive comparison for lookup
        fetchRequest.predicate = NSPredicate(format: "username ==[c] %@", username)
        fetchRequest.fetchLimit = 1 // We only need one result

        do {
            let results = try context.fetch(fetchRequest)
            return results.first // Return the first user found, or nil if none
        } catch {
            print("Error fetching user '\(username)': \(error)")
            return nil // Return nil on error
        }
    }

    // ... other SceneDelegate methods (sceneDidDisconnect, sceneDidBecomeActive, etc.) ...
    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
        // This occurs shortly after the scene enters the background, or when its session is discarded.
        // Release any resources associated with this scene that can be re-created the next time the scene connects.
        // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Called when the scene has moved from an inactive state to an active state.
        // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene will move from an active state to an inactive state.
        // This may occur due to temporary interruptions (ex. an incoming phone call).
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from the background to the foreground.
        // Use this method to undo the changes made on entering the background.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Called as the scene transitions from the foreground to the background.
        // Use this method to save data, release shared resources, and store enough scene-specific state information
        // to restore the scene back to its current state.

        // Save changes in the application's managed object context when the application transitions to the background.
        (UIApplication.shared.delegate as? AppDelegate)?.saveContext()
    }
}
