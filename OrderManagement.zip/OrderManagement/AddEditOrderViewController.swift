import UIKit
import CoreData

/// Delegate protocol to notify the presenting view controller when an order is successfully saved.
protocol AddEditOrderDelegate: AnyObject {
    /// Called when an order (new or edited) has been successfully saved to Core Data.
    func didSaveOrder()
}

/// View controller for adding a new order or editing an existing one.
class AddEditOrderViewController: UIViewController, UITextFieldDelegate {

    // MARK: - Properties

    /// Delegate to notify about save events.
    weak var delegate: AddEditOrderDelegate?
    /// The Core Data context for saving the order. Must be injected.
    var context: NSManagedObjectContext!
    /// The user creating or editing the order. Must be injected.
    var currentUser: User!
    /// The existing order being edited, or `nil` if creating a new order.
    var orderToEdit: Order?

    // MARK: - UI Elements

    private let scrollView = UIScrollView()
    private let contentView = UIView()
    // Main stack view to hold all sections vertically
    private let mainStackView = UIStackView()

    // Input Fields (declared here for easy access)
    private let customerNameTextField = UITextField()
    private let customerPhoneTextField = UITextField()
    private let customerAddressTextField = UITextField() // Assuming single field for simplicity
    private let dueDateDatePicker = UIDatePicker()
    private let orderTotalTextField = UITextField()

    // MARK: - Lifecycle Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground // Classic form background
        title = (orderToEdit == nil) ? "New Order" : "Edit Order"

        assert(context != nil, "Context must be provided to AddEditOrderViewController")
        assert(currentUser != nil, "CurrentUser must be provided to AddEditOrderViewController")

        setupScrollView()
        setupUI() // Setup the main UI structure
        setupNavigationBar()
        populateFieldsIfEditing()
        setupKeyboardDismiss()
        setupInputAccessoryView() // Add Next/Done buttons above keyboard
    }

    // MARK: - UI Setup

    /// Sets up the scroll view container.
    private func setupScrollView() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        ])
    }

    /// Creates and arranges the main UI elements and sections.
    private func setupUI() {
        // Configure the main vertical stack view
        mainStackView.axis = .vertical
        mainStackView.spacing = 25 // Space between sections
        mainStackView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(mainStackView)

        // --- Customer Information Section ---
        let customerFieldsStack = createVerticalFieldStack(fields: [
            createLabelAndFieldPair(label: "Name", textField: customerNameTextField, placeholder: "Required"),
            createLabelAndFieldPair(label: "Phone", textField: customerPhoneTextField, placeholder: "Optional", keyboardType: .phonePad)
        ])
        let customerContainer = createSectionContainer(title: "CUSTOMER", arrangedSubviews: [customerFieldsStack])

        // --- Address Section ---
        let addressFieldsStack = createVerticalFieldStack(fields: [
             createLabelAndFieldPair(label: "Address", textField: customerAddressTextField, placeholder: "Optional")
             // Could add more address fields (City, State, Zip) here if needed
        ])
        let addressContainer = createSectionContainer(title: "ADDRESS", arrangedSubviews: [addressFieldsStack])


        // --- Order Details Section ---
        configureDatePicker() // Configure date picker specifics
        let orderFieldsStack = createVerticalFieldStack(fields: [
            createLabelAndControlPair(label: "Due Date", control: dueDateDatePicker),
            createLabelAndFieldPair(label: "Total (Rs)", textField: orderTotalTextField, placeholder: "e.g., 49.99", keyboardType: .decimalPad)
        ])
        let orderContainer = createSectionContainer(title: "ORDER DETAILS", arrangedSubviews: [orderFieldsStack])


        // --- Add sections to the main stack view ---
        mainStackView.addArrangedSubview(customerContainer)
        mainStackView.addArrangedSubview(addressContainer)
        mainStackView.addArrangedSubview(orderContainer)


        // --- Set Constraints for Main StackView ---
        NSLayoutConstraint.activate([
            mainStackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            mainStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            mainStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
            mainStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20) // Defines content height
        ])
    }

    /// Configures the navigation bar Cancel and Save buttons.
    private func setupNavigationBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelTapped))
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTapped))
    }

    /// Sets the initial values of the input fields if editing an existing order.
    private func populateFieldsIfEditing() {
        guard let order = orderToEdit else { return }

        print("Populating fields for order: \(order.orderNumber)")

        customerNameTextField.text = order.customerBuyerName
        customerAddressTextField.text = order.customerAddress
        customerPhoneTextField.text = order.customerPhone
        dueDateDatePicker.date = order.orderDueDate ?? Date() // Default to now if nil
        orderTotalTextField.text = String(format: "%.2f", order.orderTotal)
    }

    /// Adds a tap gesture recognizer to dismiss the keyboard.
    private func setupKeyboardDismiss() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }

    /// Adds "Done" button above the keyboard.
    private func setupInputAccessoryView() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(dismissKeyboard))

         toolbar.setItems([flexibleSpace, doneButton], animated: false)

        customerNameTextField.inputAccessoryView = toolbar
        customerPhoneTextField.inputAccessoryView = toolbar
        customerAddressTextField.inputAccessoryView = toolbar
        orderTotalTextField.inputAccessoryView = toolbar
    }


    // MARK: - Actions

    /// Dismisses the view controller without saving changes.
    @objc private func cancelTapped() {
        dismiss(animated: true, completion: nil)
    }

    /// Validates input fields, saves the order data to Core Data, notifies the delegate, and dismisses.
    @objc private func saveTapped() {
        view.endEditing(true) // Ensure keyboard is dismissed

        // --- Validation ---
        guard let customerName = customerNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !customerName.isEmpty else {
            showAlert(title: "Missing Information", message: "Please enter the customer name.")
            customerNameTextField.becomeFirstResponder()
            return
        }

        let totalString = orderTotalTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        // Use the filtering logic in the delegate, but still validate the final string format
        guard let orderTotalValue = Double(totalString), orderTotalValue >= 0 else {
            showAlert(title: "Invalid Input", message: "Please enter a valid, non-negative number for Order Total.")
            orderTotalTextField.becomeFirstResponder()
            return
        }

        // --- Create or Update Order Object ---
        let order: Order
        if let editingOrder = orderToEdit {
            order = editingOrder // Use existing object for update
            print("Updating order: \(order.orderNumber)")
        } else {
            order = Order(context: context) // Create new managed object
            currentUser.lastOrderSequence += 1 // Increment user's counter before saving context
            order.sequenceNumber = currentUser.lastOrderSequence // Assign to order
            order.orderNumber = "ORD-\(order.sequenceNumber)" // Create display string
            print("Creating new order: \(order.orderNumber)")
        }

        // --- Assign Values from UI ---
        order.customerBuyerName = customerName
        order.orderDueDate = dueDateDatePicker.date
        order.customerAddress = customerAddressTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        order.customerPhone = customerPhoneTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        order.orderTotal = orderTotalValue // Assign validated Double

        // --- Set Relationship to User ---
        order.createdBy = currentUser

        // --- Save and Dismiss ---
        do {
            try context.save() // Saves Order and updated User (lastOrderSequence)
            print("Order and User sequence updated successfully.")
            delegate?.didSaveOrder() // Notify listener
            dismiss(animated: true, completion: nil)
        } catch {
            print("Failed to save order: \(error)")
            showAlert(title: "Save Error", message: "Could not save the order. Please try again. \(error.localizedDescription)")
        }
    }

    /// Dismisses the keyboard. Triggered by tap gesture or Done button.
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }

    // MARK: - UI Helper Methods

    /// Creates a container view for a section with a title and content.
    private func createSectionContainer(title: String?, arrangedSubviews: [UIView]) -> UIView {
        let containerStack = UIStackView()
        containerStack.axis = .vertical
        containerStack.spacing = 8

        if let title = title, !title.isEmpty {
            let headerLabel = UILabel()
            headerLabel.text = title
            headerLabel.font = UIFont.preferredFont(forTextStyle: .caption1)
            headerLabel.textColor = .secondaryLabel
            headerLabel.translatesAutoresizingMaskIntoConstraints = false
            containerStack.addArrangedSubview(headerLabel)
             containerStack.setCustomSpacing(10, after: headerLabel)
        }

        let contentContainer = UIView()
        contentContainer.backgroundColor = .secondarySystemGroupedBackground
        contentContainer.layer.cornerRadius = 10
        contentContainer.translatesAutoresizingMaskIntoConstraints = false

        let contentStack = UIStackView(arrangedSubviews: arrangedSubviews)
        contentStack.axis = .vertical
        contentStack.spacing = 15
        contentStack.alignment = .fill
        contentStack.translatesAutoresizingMaskIntoConstraints = false

        contentContainer.addSubview(contentStack)
        containerStack.addArrangedSubview(contentContainer)

        let padding: CGFloat = 15
        NSLayoutConstraint.activate([
            contentStack.topAnchor.constraint(equalTo: contentContainer.topAnchor, constant: padding),
            contentStack.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor, constant: padding),
            contentStack.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor, constant: -padding),
            contentStack.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor, constant: -padding)
        ])

        return containerStack
    }

    /// Creates a vertical stack view for related fields within a section.
    private func createVerticalFieldStack(fields: [UIView]) -> UIStackView {
        let stack = UIStackView(arrangedSubviews: fields)
        stack.axis = .vertical
        stack.spacing = 12
        stack.alignment = .fill
        return stack
    }

    /// Creates a horizontal pair of a descriptive label and a text field.
    private func createLabelAndFieldPair(label text: String, textField: UITextField, placeholder: String, keyboardType: UIKeyboardType = .default) -> UIStackView {
        let label = createFormFieldLabel(text: text)
        configureTextField(textField, placeholder: placeholder, keyboardType: keyboardType)

        let stack = UIStackView(arrangedSubviews: [label, textField])
        stack.axis = .horizontal
        stack.spacing = 8
        stack.alignment = .firstBaseline

        label.widthAnchor.constraint(greaterThanOrEqualToConstant: 80).isActive = true
        label.setContentHuggingPriority(.defaultHigh + 1, for: .horizontal)

        return stack
    }

     /// Creates a horizontal pair of a descriptive label and a generic control (like UIDatePicker).
    private func createLabelAndControlPair(label text: String, control: UIView) -> UIStackView {
        let label = createFormFieldLabel(text: text)

        let stack = UIStackView(arrangedSubviews: [label, control])
        stack.axis = .horizontal
        stack.spacing = 8
        stack.alignment = .center

        label.widthAnchor.constraint(greaterThanOrEqualToConstant: 80).isActive = true
        label.setContentHuggingPriority(.defaultHigh + 1, for: .horizontal)

        return stack
    }


    /// Creates a standard label for form fields.
    private func createFormFieldLabel(text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.preferredFont(forTextStyle: .subheadline)
        label.textColor = .label
        label.textAlignment = .right
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }

    /// Configures a text field with standard form styling.
    private func configureTextField(_ textField: UITextField, placeholder: String, keyboardType: UIKeyboardType = .default) {
        textField.placeholder = placeholder
        textField.font = UIFont.preferredFont(forTextStyle: .body)
        textField.borderStyle = .roundedRect
        textField.keyboardType = keyboardType
        textField.delegate = self // Assign delegate for filtering and return key
        textField.translatesAutoresizingMaskIntoConstraints = false
        if textField == orderTotalTextField {
             textField.returnKeyType = .done
        } else {
             textField.returnKeyType = .next
        }
        textField.heightAnchor.constraint(greaterThanOrEqualToConstant: 40).isActive = true
    }

    /// Configures the date picker.
    private func configureDatePicker() {
        dueDateDatePicker.datePickerMode = .dateAndTime
        dueDateDatePicker.preferredDatePickerStyle = .compact
        dueDateDatePicker.minimumDate = Calendar.current.startOfDay(for: Date())
        dueDateDatePicker.translatesAutoresizingMaskIntoConstraints = false
        dueDateDatePicker.setContentHuggingPriority(.defaultLow - 1, for: .horizontal)
    }

    /// Displays a simple alert controller.
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // MARK: - UITextFieldDelegate

    /// Handles the return key press on the keyboard to move between fields or save.
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case customerNameTextField:
            customerPhoneTextField.becomeFirstResponder()
        case customerPhoneTextField:
            customerAddressTextField.becomeFirstResponder()
        case customerAddressTextField:
            orderTotalTextField.becomeFirstResponder()
        case orderTotalTextField:
            saveTapped() // Attempt save on Done
        default:
            textField.resignFirstResponder()
        }
        return true
    }

    /// Filters input characters based on the text field type.
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        // Allow backspace/delete unconditionally
        if string.isEmpty {
            return true
        }

        // Get the current text and the potential new text
        let currentText = textField.text ?? ""
        guard let stringRange = Range(range, in: currentText) else { return false }
        let updatedText = currentText.replacingCharacters(in: stringRange, with: string)


        // --- Phone Number Filtering ---
        if textField == customerPhoneTextField {
            let allowedCharacters = CharacterSet(charactersIn: "0123456789+-() ") // Allow common phone chars
            let characterSet = CharacterSet(charactersIn: string)
            // Optional: Limit length
            // let maxLength = 15
            // guard updatedText.count <= maxLength else { return false }
            return allowedCharacters.isSuperset(of: characterSet)
        }

        // --- Order Total Filtering (Decimal) ---
        if textField == orderTotalTextField {
            let allowedCharacters = CharacterSet(charactersIn: "0123456789.")
            let characterSet = CharacterSet(charactersIn: string)

            // Check 1: Ensure only allowed characters are entered
            guard allowedCharacters.isSuperset(of: characterSet) else {
                return false
            }

            // Check 2: Ensure only one decimal point is allowed
            let existingTextHasDecimal = currentText.contains(".")
            let replacementTextHasDecimal = string.contains(".")
            if existingTextHasDecimal && replacementTextHasDecimal {
                return false
            }

            // Check 3: Limit number of digits after decimal point
            if let decimalSeparatorIndex = updatedText.firstIndex(of: ".") {
                let fractionPart = updatedText[updatedText.index(after: decimalSeparatorIndex)...]
                if fractionPart.count > 2 {
                     print("Attempted to enter more than 2 decimal places.")
                     return false
                }
            }

            return true
        }

        // Default: Allow changes for other fields (Name, Address)
        return true
    }
}
